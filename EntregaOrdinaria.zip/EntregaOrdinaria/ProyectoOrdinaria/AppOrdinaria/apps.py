from django.apps import AppConfig


class AppordinariaConfig(AppConfig):
    name = 'AppOrdinaria'
